import React from 'react';
import ProductCard from '../ProductCard/ProductCard';
import { Link } from 'react-router-dom';

class ProductsList extends React.Component {
  render() {
    const { products, notFound } = this.props;
    console.log(products);

    return (
      <div>
        {notFound && <p>Nenhum produto foi encontrado</p>}
        {products &&
          products.map((data) => (
            <Link to={`/product/${data.id}`} data-testid="product-detail-link">
              <div key={data.id}>
                <ProductCard key={data.id} product={data} />
              </div>
            </Link>
          ))}
      </div>
    );
  }
}

export default ProductsList;
